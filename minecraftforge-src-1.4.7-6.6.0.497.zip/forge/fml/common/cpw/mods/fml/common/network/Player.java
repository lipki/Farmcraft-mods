package cpw.mods.fml.common.network;

/**
 *
 * @author cpw
 *
 */
public interface Player
{

}
