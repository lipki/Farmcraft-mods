package cpw.mods.fml.common.registry;

public interface BlockProxy
{

}
